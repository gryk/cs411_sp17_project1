# Sport-specific schedule and results
The results and the upcoming schedule for Illini sports are both found on the same page (for each sport).  For instance, the men's basketball schedule/results are found at: http://www.fightingillini.com/schedule.aspx?path=mbball&
The key components for our purposes are the date, time and place.  These (along with a name) define the primary key for the sporting event.  Date and time are listed first for each event.  The place is listed in the second column. As for the name, MG has been using the opponent's name along with a numeric suffix.  The suffix is not necessary, as all four components make up the primary key.  The suffix is for the guidance of the DBA.

[[images/Sports_01.png]]

As a convention, the place is the name of the arena if available (ex. State Farm Arena) or City, ST if no arena.  If the time is TBD then we default to noon.

The actual performance stats are found by following either the pdf link or the "box scores" link.  One challenge is that the box score link uses a numeric key of the Illinois database and therefore it is not obvious what the event is.  Similarly, the pdf's use a standard naming convention which differs from our ID.

[[images/Sports_02.png]]

In the case shown above, the name of the event is "Washington" but the abbreviation is "Wash U".  We would need to scan based primarily on date to resolve this.

[[images/Sports_03.png]]

Finally, the only stats of interest to us are the ones for the Illinois team .

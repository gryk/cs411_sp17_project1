CREATE DATABASE  IF NOT EXISTS `michaelsdb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `michaelsdb`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: michaelsinstance.cg5hjai80h9e.us-east-1.rds.amazonaws.com    Database: michaelsdb
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Athletes`
--

DROP TABLE IF EXISTS `Athletes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Athletes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstName` varchar(16) NOT NULL,
  `lastName` varchar(32) NOT NULL,
  `picture` varchar(128) DEFAULT NULL,
  `hometown` varchar(128) DEFAULT NULL,
  `class` varchar(8) DEFAULT NULL,
  `sportName` varchar(32) NOT NULL,
  `jerseyNumber` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sportName` (`sportName`),
  CONSTRAINT `Athletes_ibfk_1` FOREIGN KEY (`sportName`) REFERENCES `Sports` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Athletes`
--

LOCK TABLES `Athletes` WRITE;
/*!40000 ALTER TABLE `Athletes` DISABLE KEYS */;
INSERT INTO `Athletes` VALUES (1,'D.J.','Williams','http://www.fightingillini.com/images/2016/9/1/Williams_DJ_Headshot_082116_2MJ0870.JPG','Chicago, IL','So.','basketball',0),(2,'Leron','Black','http://www.fightingillini.com/images/2016/9/1/Black_Leron_Headshot_082116_2MJ0847_35.JPG','Memphis, TN','R-So.','basketball',12),(3,'Maverick','Morgan','http://www.fightingillini.com/images/2016/9/1/Morgan_Maverick_Headshot_082116_2MJ0875.JPG','Springboro, OH','Sr.','basketball',22),(4,'Te\'Jon','Lucas','http://www.fightingillini.com/images/2016/9/1/Lucas_Tejon_Headshot_082116_2MJ0901.JPG','Milwaukee, WI','Fr.','basketball',3),(5,'Tracy','Abrams','http://www.fightingillini.com/images/2016/9/1/Abrams_Tracy_Headshot_082116_2MJ0868_49.JPG','Chicago, IL','Gr.','basketball',13),(6,'Malcolm','Hill','http://www.fightingillini.com/images/2016/9/1/Hill_Malcolm_Headshot_082116_2MJ0886.JPG','Fairview Heights, IL','Sr.','basketball',21),(7,'Kipper','Nichols','http://www.fightingillini.com/images/2016/9/1/Nichols_Kipper_Headshot_082116_2MJ0907.JPG','Cleveland, OH','R-Fr.','basketball',2),(8,'Jalen','Coleman-Lands','http://www.fightingillini.com/images/2016/9/1/Coleman_Lands_Jalen_Headshot_082116_2MJ0839.JPG','Indianapolis, IN','So.','basketball',5),(9,'Michael','Finke','http://www.fightingillini.com/images/2016/9/1/Finke_Michael_Headshot_082116_2MJ0893.JPG','Champaign, IL','R-So.','basketball',43),(10,'Kiana','Sherlund','http://www.fightingillini.com/images/2016/12/16/Sherlund_Kiana_2MJ0703.jpg','Fairfax, VA','So.','softball',6),(11,'Alyssa','Gunther','http://www.fightingillini.com/images/2016/12/16/Gunther_Alyssa_2MJ0750.jpg','Tinley Park, IL','Sr.','softball',2),(12,'Annie','Flemming','http://www.fightingillini.com/images/2016/12/16/Fleming_Annie_2MJ0663.jpg','Chillicothe, IL','Jr.','softball',99),(13,'Nicole','Evans','http://www.fightingillini.com/images/2016/12/16/Evans_Nicole_2MJ0753.jpg','Glen Ellyn, IL','Sr.','softball',40),(14,'Sam','Acosta','http://www.fightingillini.com/images/2016/12/16/Acosta_Sam_2MJ0674.jpg','Hoffman Estates, IL','Jr.','softball',31),(15,'Stephanie','Abello','http://www.fightingillini.com/images/2016/12/16/Abello_Stephanie_2MJ0712.jpg','Batavia, IL','So.','softball',77),(16,'Jill','Nicklas','http://www.fightingillini.com/images/2016/12/16/Nicklas_Jill_2MJ0745.jpg','McKinney, TX','Jr.','softball',52),(17,'Ruby','Rivera','http://www.fightingillini.com/images/2016/12/16/Rivera_Ruby_2MJ0707.jpg','Glendale, CA','Sr.','softball',42),(18,'Emily','Brodner','http://www.fightingillini.com/images/2016/12/16/Brodner_Emily_2MJ0658.jpg','St. Charles, IL','R-So.','softball',11),(19,'Kate','Giddens','http://www.fightingillini.com/images/2016/12/16/Giddens_Kate_2MJ0680.jpg','Milledgeville, GA','Jr.','softball',88),(20,'Leigh','Farina','http://www.fightingillini.com/images/2016/12/16/Farina_Leigh_2MJ0693.jpg','Rolling Meadows, IL','Jr.','softball',23),(21,'Veronica','Ruelius','http://www.fightingillini.com/images/2016/12/16/Ruelius_Veronica_2MJ0688.jpg','Marengo, IL','R-Fr.','softball',0),(22,'Maddi','Doane','http://www.fightingillini.com/images/2016/12/16/Doane_Maddi_2MJ0723.jpg','Bolingbrook, IL','Jr.','softball',14),(23,'Breanna','Wonderly','http://www.fightingillini.com/images/2016/12/16/Wonderly_Breanna_2MJ0716.jpg','Centerview, MO','Sr.','softball',20),(24,'Danielle','Brochu','http://www.fightingillini.com/images/2016/12/16/Brochu_Danielle_2MJ0732.jpg','Lucas, TX','So.','softball',1),(25,'Taylor','Edwards','http://www.fightingillini.com/images/2016/12/16/Edwards_Taylor_2MJ0736.jpg','Arcola, IL','So.','softball',12),(26,'Akilah','Mouzon','http://www.fightingillini.com/images/2016/12/16/Mouzon_Akilah_2MJ0665.jpg','Newwark, NJ','Fr.','softball',4),(27,'Alexis','Carillo','http://www.fightingillini.com/images/2016/12/16/Carrillo_Alexis_2MJ0718.jpg','Lakewood, CA','So.','softball',3),(28,'Erin','Walker','http://www.fightingillini.com/images/2016/12/16/Walker_Erin_2MJ0699.jpg','Tuscola, IL','Jr.','softball',5),(29,'Hanna','Nilsen','http://www.fightingillini.com/images/2016/12/16/Nilsen_Hanna_2MJ0669.jpg','Trabuco Canyon, CA','Fr.','softball',98),(30,'Katie','Gallagher','http://www.fightingillini.com/images/2016/12/16/Gallagher_Katie_2MJ0741.jpg','Chicago, IL','Jr.','softball',13),(31,'Rowan','McGuire','http://www.fightingillini.com/images/2016/12/16/McGuire_Rowan_2MJ0726.jpg','Downer\'s Grove, IL','Jr.','softball',17),(32,'Carly','Thomas','http://www.fightingillini.com/images/2016/12/16/Thomas_Carly_2MJ0691.jpg','Fontana, CA','Jr.','softball',25),(33,'Siena','Sandoval','http://www.fightingillini.com/images/2016/12/16/Sandoval_Siena_2MJ0678.jpg','Upland, CA','Fr.','softball',33),(34,'Jaylon','Tate','http://www.fightingillini.com/images/2016/9/1/Tate_Jaylon_Headshot_082116_2MJ0892.JPG','Chicago, IL','So.','basketball',1),(35,'Drew','Cayce','http://www.fightingillini.com/images/2016/9/1/Cayce_Drew_Headshot_082116_2MJ0915.JPG','Libertyville, IL','So.','basketball',10),(36,'Aaron','Jordan','http://www.fightingillini.com/images/2016/9/1/Jordan_Aaron_Headshot_082116_2MJ0851.JPG','Plainfield, IL','So.','basketball',23),(37,'Mike','Thorne Jr.','http://www.fightingillini.com/images/2016/9/1/Thorne_Jr_Mike_Headshot_082116_2MJ0919.JPG','Fayetteville, NC','Gr.','basketball',33),(38,'Samson','Oladimeji','http://www.fightingillini.com/images/2016/9/1/Liss_Cameron_Headshot_082116_2MJ0841_44.JPG','Rolling Meadows, IL','Fr.','basketball',35),(39,'Clayton','Jones','http://www.fightingillini.com/images/2016/9/1/Jones_Clayton_Headshot_082116_2MJ0928.JPG','Champaign, IL','Jr.','basketball',41),(40,'Alex','Austin','http://www.fightingillini.com/images/2016/9/1/Austin_Alex_Headshot_082116_2MJ0857.JPG','Chicago, IL','R-Sr.','basketball',44),(41,'Cameron','Liss','http://www.fightingillini.com/images/2016/9/1/Liss_Cameron_Headshot_082116_2MJ0841_44.JPG','Northbrook, IL','Jr.','basketball',45);
/*!40000 ALTER TABLE `Athletes` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-24 10:04:16

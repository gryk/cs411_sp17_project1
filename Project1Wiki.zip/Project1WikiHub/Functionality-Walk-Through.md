# User enters their username and password
1. We will pre-populate with all network ID's scraped from project Wiki w/password same as network ID's)
1. User can also click a link to create an account by specifying a username and password (MG: do we still want this?)
1. Once logged in, the users sees...

## A. 1 tab for each active tournaments of which they are a participant
1. Information about the performance of each of their athletes in this tournament - aggregate and weekly
2. Information about how the various teams participating are ranked (including their own team's placement)

## B. Tab for all other active tournaments
All tournaments names are links.
### Clicking one of the tournaments
1. Information about how the tournament is scored
1. Rankings of each team in the tournament

## C. Tab for all tournaments awaiting sufficient teams
1. Table with a column for the tournament name and a column describing the scoring criteria
1. Each item in the list is a link (if they have joined fewer than 2 tournaments still running)

### Joining a tournament
1. User sees list of sports participating in the tournament
1. User chooses a sport and sees available athletes from that sport
1. User chooses an athlete
1. If that was the last athlete required for their team, they go to step 1 again, otherwise they are enrolled in the tournament
1. If this team was the last required for the tournament, it is now activated

## D. Tab for student stats
1. Textbox where a user's name can be typed in, with proactive suggestion of name matches
1. Clicking "submit" goes to a page that shows a raw dump of statistics for that athlete & picture (if available)

## E. Link to create a new tournament (if they have fewer than 2 tournaments running that they created)
1. User chooses sports to add to the tournament
1. As sports are added, available seasons of data to play through the system may change (not all seasons available for all sports)
1. User chooses seasons to play through the system from available selections
1. User chooses number of teams to allow

### User enters scoring criteria for the tournament

**Wrapping of SQL in “syntactic sugar” is advanced feature #1**

1. Boils down to defining how to calculate 1 “standardized point” for each participating sport
1. Example: .5 of Style Points for Gymnastics, .25 Touchdowns for Football)

**“Weekly Percentages above Norm” is a data point we can synthesize as advanced feature #2**

## F. 1 tab for each tournament they created
1. Link to advance the week

## G. Link to logout





Imgur link with album of images: http://imgur.com/a/bVdxZ

![](http://i.imgur.com/BcnGV9S.png)

![](http://i.imgur.com/3AUMsf3.jpg)

![](http://i.imgur.com/1jFSmH2.png)

![](http://i.imgur.com/Q1oyA32.png)

![Mockup of realtime stat superposition](https://github.com/ProximitorErin/MichaelsCodeRepo/blob/master/Misc/Black_Leron_Headshot_fantasy.png)
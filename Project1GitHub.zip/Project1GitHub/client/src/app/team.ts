export interface ITeam
{
    name : string;
    wins : number;
    username : string;
    tournamentName : string;
    tournamentStart : string;
    tournamentEnd : string;
}
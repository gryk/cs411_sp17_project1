| Task | Expertise | Member | By Midterm | Dependency |
| --- | --- | --- | --- | --- |
| Creating DB Schema | SQL | Any | Yes | _ |
| Creating REST Services | Java and Spring boot | Derek, Michael L. | Yes | 3 |
| Creating SQL for REST Services | SQL | Any | Yes | 1 |
| SQL or Advance #1: Ad hoc scoring | Advanced SQL | Any | No |  _ |
| SQL for Advanced #2: Deviation from Mean Stat | Advanced SQL | Any | No |  _ |
| Creating Angular 2 screens | JavaScript & Angular | Michael G, Derek | Yes | 2 |
| Scraping and population code | SQL and some scripting languages | Any | No |  _ |
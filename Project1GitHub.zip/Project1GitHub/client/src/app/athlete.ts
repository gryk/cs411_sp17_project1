// Got the case wrong
export interface IAthlete
{
    image : string;
    text : string;
}
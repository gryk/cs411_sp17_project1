# Skype Link

https://join.skype.com/Dd5y3bjlidgT

# CS411 Links

[The Michaels](https://wiki.illinois.edu/wiki/display/cs411sp17/The+Michaels)

# Tutorials

* [Spring Boot](https://spring.io/guides/gs/spring-boot/)
* [Angular](https://angular.io/docs/ts/latest/tutorial/)
* [Angular-CLI](https://angular.io/docs/ts/latest/tutorial/)

# Illinois Sports

* [Illinois sports](http://www.fightingillini.com/calendar.aspx)
* [Illini Roster Sample](http://www.fightingillini.com/roster.aspx?rp_id=7212&path=mgym)

# Professional Sports

* http://suredbits.com/api/
* [NFL Fantasy](http://www.nfl.com/fantasyfootball/help/nfl-scoringsettings#settings)

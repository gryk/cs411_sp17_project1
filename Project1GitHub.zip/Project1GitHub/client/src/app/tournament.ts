export interface ITournament
{
    name : string;
    startDate : string;
    endDate : string;
    teamSize : number;
    teamCount : number;
    sername : string;
}
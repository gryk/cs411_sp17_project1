import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tournament-update',
  templateUrl: './tournament-update.component.html',
  styleUrls: ['./tournament-update.component.css']
})
export class TournamentUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

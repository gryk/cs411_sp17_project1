export interface IStatistic
{
    sportName : string;
    statName : string;
    weight: number;
}
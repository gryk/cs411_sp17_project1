export interface IDailyStatForAthlete
{
    data : number[];
    label : string;
}
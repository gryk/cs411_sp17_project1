CREATE DATABASE  IF NOT EXISTS `michaelsdb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `michaelsdb`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: michaelsinstance.cg5hjai80h9e.us-east-1.rds.amazonaws.com    Database: michaelsdb
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Teams`
--

DROP TABLE IF EXISTS `Teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Teams` (
  `name` varchar(128) NOT NULL,
  `wins` int(11) DEFAULT '0',
  `username` varchar(16) NOT NULL,
  `tournamentName` varchar(128) NOT NULL,
  `tournamentStart` date NOT NULL,
  `tournamentEnd` date NOT NULL,
  PRIMARY KEY (`name`,`username`,`tournamentName`),
  KEY `fk_tournaments_teams` (`tournamentName`,`tournamentStart`,`tournamentEnd`),
  CONSTRAINT `fk_tournaments_teams` FOREIGN KEY (`tournamentName`, `tournamentStart`, `tournamentEnd`) REFERENCES `Tournaments` (`name`, `startDate`, `endDate`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Teams`
--

LOCK TABLES `Teams` WRITE;
/*!40000 ALTER TABLE `Teams` DISABLE KEYS */;
INSERT INTO `Teams` VALUES ('MichaelsBest',0,'gryk2','WinnerTakeAll','2017-02-24','2017-03-06'),('UNCREATED_atom',0,'atom','atom_test','2017-03-10','2017-03-17'),('UNCREATED_derekf2',0,'derekf2','atom_test','2017-03-10','2017-03-17'),('UNCREATED_derekf2',0,'derekf2','Mike\'s Tournament','2017-02-20','2017-03-05'),('UNCREATED_derekf2',0,'derekf2','Report_Challenge','2017-02-20','2017-03-05'),('UNCREATED_derekf2',0,'derekf2','WinnerTakeAll','2017-02-24','2017-03-06'),('UNCREATED_Report_Challenge',0,'Report_Challenge','Report_Challenge','2017-02-20','2017-03-05');
/*!40000 ALTER TABLE `Teams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-24 10:04:15

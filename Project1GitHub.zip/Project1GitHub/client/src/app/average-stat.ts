export interface IAverageStat
{
    sportName : string;
    statName : string;
    statValue: number;
}
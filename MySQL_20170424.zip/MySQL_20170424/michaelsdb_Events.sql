CREATE DATABASE  IF NOT EXISTS `michaelsdb` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `michaelsdb`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: michaelsinstance.cg5hjai80h9e.us-east-1.rds.amazonaws.com    Database: michaelsdb
-- ------------------------------------------------------
-- Server version	5.6.27-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Events`
--

DROP TABLE IF EXISTS `Events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Events` (
  `name` varchar(32) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `place` varchar(32) NOT NULL,
  PRIMARY KEY (`name`,`date`,`time`,`place`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Events`
--

LOCK TABLES `Events` WRITE;
/*!40000 ALTER TABLE `Events` DISABLE KEYS */;
INSERT INTO `Events` VALUES ('Auburn','2017-03-18','11:00:00','Tampa'),('Bethune-Cookman','2017-03-19','10:15:00','Tampa'),('Bradley','2017-03-22','18:00:00','Eichelberger Field'),('Butler','2017-04-19','17:00:00','Eichelberger Field'),('California 1','2017-02-12','07:00:00','Donna Terry Stadium'),('California 2','2017-02-17','15:30:00','Big League Dreams'),('Chattanooga','2017-03-17','17:15:00','Tampa'),('Eastern Illinois','2017-05-02','17:00:00','Eichelberger Field'),('Florida Atlantic','2017-03-03','14:30:00','Tiger Park'),('Georgia State 1','2017-02-24','13:00:00','Heck Softball Complex'),('Georgia State 2','2017-02-24','15:30:00','Heck Softball Complex'),('Georgia Tech 1','2017-02-10','11:30:00','Puerto Rican Stadium'),('Georgia Tech 2','2017-02-11','12:30:00','Puerto Rican National'),('Georgia Tech 3','2017-02-26','13:00:00','Mewborn Field'),('Illinois State','2017-03-03','12:00:00','Tiger Park'),('Illinois State','2017-03-29','17:00:00','Eichelberger Field'),('Indiana','2017-01-07','16:00:00','Bloomington, IN'),('Iowa','2017-01-25','20:00:00','State Farm Center'),('Iowa','2017-03-24','17:30:00','Pearl Field'),('Iowa','2017-03-25','13:00:00','Pearl Field'),('Iowa','2017-03-26','12:00:00','Pearl Field'),('Kennesaw State 1','2017-02-25','13:00:00','Bailey Park'),('Kennesaw State 2','2017-02-25','16:50:00','Bailey Park'),('LIU','2017-03-17','15:00:00','Tampa'),('Lousianna State','2017-03-04','18:25:00','Tiger Park'),('Maryland','2017-01-14','17:00:00','State Farm Center'),('Michigan','2017-01-11','20:00:00','State Farm Center'),('Michigan','2017-01-21','13:15:00','Ann Arbor, MI'),('Michigan State','2017-03-01','20:00:00','State Farm Center'),('Michigan State','2017-04-14','15:00:00','Secchia Stadium'),('Michigan State','2017-04-15','12:00:00','Secchia Stadium'),('Michigan State','2017-04-16','12:00:00','Secchia Stadium'),('Minnesota','2017-02-04','15:00:00','State Farm Center'),('Minnesota','2017-03-31','17:00:00','Eichelberger Field'),('Minnesota','2017-04-01','13:00:00','Eichelberger Field'),('Minnesota','2017-04-02','12:00:00','Eichelberger Field'),('Missouri','2017-03-08','19:15:00','Lindenwood'),('Nebraska','2017-02-26','18:36:00','Pinnacle Bank Arena'),('Nebraska','2017-04-21','17:30:00','Bowlin Stadium'),('Nebraska','2017-04-22','15:00:00','Bowlin Stadium'),('Nebraska','2017-04-23','12:00:00','Bowlin Stadium'),('North Carolina 1','2017-02-10','10:00:00','Estadio Donna Terry'),('North Carolina 2','2017-02-11','10:00:00','Puerto Rican Stadium'),('Northwestern','2017-02-07','19:00:00','Evanston, IL'),('Northwestern','2017-02-21','19:00:00','State Farm Center'),('Northwestern','2017-04-05','16:00:00','Drysdale Field'),('Ohio State','2017-01-01','18:00:00','State Farm Center'),('Ohio State','2017-05-05','17:00:00','Eichelberger Field'),('Ohio State','2017-05-06','13:00:00','Eichelberger Field'),('Ohio State','2017-05-07','12:00:00','Eichelberger Field'),('Oregon','2017-02-19','09:00:00','Big League Dreams'),('Penn State','2017-01-28','15:30:00','University Park, PA'),('Penn State','2017-02-11','13:00:00','State Farm Center'),('Purdue','2017-01-17','18:00:00','West Lafayette, IN'),('Purdue','2017-04-07','17:00:00','Eichelberger Field'),('Purdue','2017-04-08','13:00:00','Eichelberger Field'),('Purdue','2017-04-09','12:00:00','Eichelberger Field'),('Rutgers','2017-03-04','11:00:00','Piscataway, NJ'),('Saint Marys','2017-02-17','12:00:00','Big League Dreams'),('SIUE','2017-04-11','17:00:00','Eichelberger Field'),('Troy 1','2017-03-04','11:20:00','Tiger Park'),('Troy 2','2017-03-05','09:00:00','Tiger Park'),('UIC','2017-03-21','15:00:00','Eichelberger Field'),('USF','2017-03-18','15:45:00','Tampa'),('Wisconsin','2017-01-31','20:00:00','State Farm Center'),('Wisconsin','2017-04-28','17:00:00','Eichelberger Field'),('Wisconsin','2017-04-29','13:00:00','Eichelberger Field'),('Wisconsin','2017-04-30','12:00:00','Eichelberger Field');
/*!40000 ALTER TABLE `Events` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-24 10:04:17
